echo "|-----------------------------------------------------|"
echo "|   YOURE BITCH IS SO LAZY TO DO THIS SHIT YOURSELF   |"
echo "|-----------------------------------------------------|"
# ensure we are in the correct directory if install.sh, generate-config.sh, generate-client-config.sh, diagnose.sh, test-keys-from-keys-file.sh, test-client-keys.sh are in the same directory

if [ ! -f install.sh ] || [ ! -f generate-config.sh ] || [ ! -f generate-client-config.sh ] || [ ! -f diagnose.sh ] || [ ! -f test-keys-from-keys-file.sh ] || [ ! -f test-client-keys.sh ]; then
    echo "Error: scripts are not in the correct directory"
    exit 1
fi

./install.sh
./generate-config.sh --clients 2
./generate-client-config.sh --server-address $(curl -s https://icanhazip.com):8443
docker compose up -d
./diagnose.sh
./test-keys-from-keys-file.sh
./test-client-keys.sh client-windows/client.toml

echo "Done\n\nYour server is running on port 8443/UDP\n--------------------------------\nCONFIG: ./server/server.toml\nCLIENT KEYS: ./server/client-keys.txt"