use super::{ClientTransport, ConnectionResult};
use crate::auth::{AuthHandler, UdpAuthChannel};
use crate::config::{CoreConfig, ServerConfig};
use crate::socket::AnetUdpSocket;
use anet_common::encryption::Cipher;
use anet_common::quic_settings::build_transport_config;
use anyhow::Result;
use async_trait::async_trait;
use log::info;
use quinn::{ClientConfig, Endpoint, EndpointConfig, RecvStream, SendStream, TokioRuntime};
use rustls::RootCertStore;
use std::io;
use std::net::{SocketAddr, ToSocketAddrs};
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
use tokio::net::UdpSocket;
use anet_common::consts::PADDING_MTU;

pub struct QuicDuplexStream {
    send: SendStream,
    recv: RecvStream,
}

impl AsyncRead for QuicDuplexStream {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<std::io::Result<()>> {
        Pin::new(&mut self.recv).poll_read(cx, buf)
    }
}

impl AsyncWrite for QuicDuplexStream {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<std::io::Result<usize>> {
        Pin::new(&mut self.send)
            .poll_write(cx, buf)
            .map(|result| result.map_err(io::Error::other))
    }
    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        Pin::new(&mut self.send)
            .poll_flush(cx)
            .map(|result| result.map_err(io::Error::other))
    }
    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<std::io::Result<()>> {
        Pin::new(&mut self.send)
            .poll_shutdown(cx)
            .map(|result| result.map_err(io::Error::other))
    }
}

pub struct QuicTransport {
    config: CoreConfig,
    server: ServerConfig, // Сохраняем индивидуальные параметры ноды
}

impl QuicTransport {
    pub fn new(config: CoreConfig, server: ServerConfig) -> Self {
        Self { config, server }
    }
}

#[async_trait]
impl ClientTransport for QuicTransport {
    async fn connect(&self) -> Result<ConnectionResult> {
        // Вытаскиваем адрес конкретной ноды
        let addr_str = self.server.endpoint()?;
        let server_addr: SocketAddr = addr_str
            .to_socket_addrs()?
            .next()
            .ok_or_else(|| anyhow::anyhow!("Invalid server address"))?;
        let udp_socket = Arc::new(UdpSocket::bind("0.0.0.0:0").await?);
        let channel = UdpAuthChannel::new(udp_socket.clone(), server_addr);

        // Передаем опциональный ключ сервера для переопределения
        let auth_handler = AuthHandler::new(&self.config, self.server.server_pub_key.as_deref())?;
        let (auth_response, shared_key) = auth_handler.authenticate(&channel).await?;

        let mut quic_cfg = self.config.quic_transport.clone();
        // Для клиентского соединения выставляем надежный keep-alive (10s) во избежание
        // сброса NAT мобильными операторами/роутерами и разумный idle timeout (30s),
        // чтобы обрыв сети определялся за полминуты, а не висел часами без интернета.
        quic_cfg.keep_alive_interval_seconds = Some(
            quic_cfg.keep_alive_interval_seconds.unwrap_or(10).min(10)
        );
        quic_cfg.idle_timeout_seconds = Some(
            quic_cfg.idle_timeout_seconds.unwrap_or(30).min(30)
        );

        let transport_config =
            build_transport_config(&quic_cfg, auth_response.mtu as u16)?;

        let cipher = Arc::new(Cipher::new(&shared_key));
        let nonce_prefix: [u8; 4] = auth_response
            .nonce_prefix
            .as_slice()
            .try_into()
            .map_err(|_| anyhow::anyhow!("Invalid nonce prefix len"))?;

        let anet_socket = Arc::new(AnetUdpSocket::new(
            udp_socket,
            cipher,
            nonce_prefix,
            self.config.stealth.clone(),
        ));

        let mut ep_config = EndpointConfig::default();
        let _ = ep_config.max_udp_payload_size(PADDING_MTU as u16);

        let mut endpoint = Endpoint::new_with_abstract_socket(
            ep_config,
            None,
            anet_socket,
            Arc::new(TokioRuntime),
        )?;

        let mut root_store = RootCertStore::empty();
        for cert in rustls_pemfile::certs(&mut auth_response.quic_cert.as_slice()) {
            root_store.add(cert?)?;
        }

        let client_crypto = rustls::ClientConfig::builder()
            .with_root_certificates(root_store)
            .with_no_client_auth();

        let mut client_config = ClientConfig::new(Arc::new(
            quinn::crypto::rustls::QuicClientConfig::try_from(client_crypto)?,
        ));
        client_config.transport_config(Arc::new(transport_config));
        endpoint.set_default_client_config(client_config);

        info!("[QUIC] Connecting to {}...", server_addr);
        let connection = endpoint.connect(server_addr, "alco")?.await?;

        info!(
            "[QUIC] Connection established. SEID: {}",
            auth_response.session_id
        );

        let (send, recv) = connection.open_bi().await?;
        let stream = QuicDuplexStream { send, recv };

        Ok(ConnectionResult {
            auth_response,
            vpn_stream: Box::new(stream),
            endpoint: Some(endpoint),
            connection: Some(connection),
            health_pause: None,
        })
    }
}
